﻿using System.ComponentModel.DataAnnotations;

namespace BlobApp.Models
{
    public class UploadImage
    {
        [Required]

        [Display(Name = "Image")]

        public IFormFile Image { get; set; }

    }
}
