using Microsoft.AspNetCore.Mvc;
using BlobApp.Models;
using BlobApp.Services;

namespace BlobApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly BlobStorageServices _blobService;

        private readonly BlobStorageServices _blobStorageService;

        public HomeController(BlobStorageServices blobStorageService)
        {
            _blobStorageService = blobStorageService;
        }


        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Upload(UploadImage model)
        {
            if (model.Image != null && model.Image.Length > 0)
            {
                // Upload the image to Blob Storage
            var imageUrl = await _blobStorageService.UploadAsync(model.Image);
                ViewBag.ImageUrl = imageUrl;
            }
            return View("Index");
        }


    }
}
