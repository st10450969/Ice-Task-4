﻿using BlobApp.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc;
using BlobApp.Models;


namespace BlobApp.Controllers
{
    public class ImageController : Controller
    {
        private readonly BlobStorageServices _blobService;

        public ImageController(BlobStorageServices blobService)
        {
            _blobService = blobService;
        }

        [HttpGet]
        public IActionResult Upload()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Upload(UploadImage model)
        {
            if (ModelState.IsValid && model.Image != null)
            {
                var url = await _blobService.UploadAsync(model.Image);
                ViewBag.ImageUrl = url;
            }
            return View();

        }
    }
}
