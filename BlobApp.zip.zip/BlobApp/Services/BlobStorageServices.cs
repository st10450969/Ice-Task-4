﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.IO;
using System.Threading.Tasks;

namespace BlobApp.Services
{
    public class BlobStorageServices
    {
        private readonly string _connectionString;
        private readonly string _containerName;

        public BlobStorageServices(IConfiguration config)
        {
            _connectionString = config["AzureBlobStorage:ConnectionString"];
            _containerName = config["AzureBlobStorage:ContainerName"];
        }

        public async Task<string> UploadAsync(IFormFile file)
        {
            // Create a blob client for the container
            var container = new BlobContainerClient(_connectionString, _containerName);
            await container.CreateIfNotExistsAsync(PublicAccessType.Blob);

            // Generate a unique file name using GUID
            string fileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
            var blob = container.GetBlobClient(fileName);

            // Upload the file to Blob Storage
            using (var stream = file.OpenReadStream())
            {
                await blob.UploadAsync(stream, new BlobHttpHeaders { ContentType = file.ContentType });
            }

            // Return the URL of the uploaded file
            return blob.Uri.ToString();
        }


    }
}
